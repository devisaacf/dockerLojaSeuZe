<?php
// $host = 'localhost';
// $usuario = 'root';
// $senha = '';
// $banco = 'lojaze';
// $porta = 3406;

$host = 'loja_db'; // nome do serviço MySQL no docker-compose
$usuario = 'root';
$senha = 'root'; // ou '' se estiver sem senha no compose
$banco = 'lojaze';
$porta = 3306;

$conexao = new mysqli($host, $usuario, $senha, $banco, $porta);

if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}
?>
