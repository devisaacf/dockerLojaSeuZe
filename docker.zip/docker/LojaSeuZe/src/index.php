<?php
header("Location: home.html");
exit;
